import cv2
import numpy as np
import math

#功能：使用导向滤波处理颜色失真

def guideFilter(I, p, winSize, eps):
    
    #I的均值平滑
    mean_I = cv2.blur(I, winSize)
    
    #p的均值平滑
    mean_p = cv2.blur(p, winSize)
    
    #I*I和I*p的均值平滑
    mean_II = cv2.blur(I*I, winSize)
    
    mean_Ip = cv2.blur(I*p, winSize)
    
    #方差
    var_I = mean_II - mean_I * mean_I #方差公式
    
    #协方差
    cov_Ip = mean_Ip - mean_I * mean_p
   
    a = cov_Ip / (var_I + eps)
    b = mean_p - a*mean_I
    
    #对a、b进行均值平滑
    mean_a = cv2.blur(a, winSize)
    mean_b = cv2.blur(b, winSize)
    
    q = mean_a*I + mean_b
    
    return q

def videoProcess(frame):
#传入视频帧，返回去雾处理后的帧，即可实现实时去雾
    defog=fastdehaze(frame/255.0)*255
    m=defog.astype('uint8')
    res=adjustContractAndBrithtness(m)
    return res
def fastdehaze(img):

    h=img.shape[0]
    w=img.shape[1]
    M=np.zeros((h,w))
    M=img#提取rgb三通道最小值
    m_av=np.mean(M)#提取M中所有元素均值
    M_ave=guideFilter(M,M,(16,16),0.01)#导向滤波
    T=np.zeros((h,w))
    e=3.0
    T= M_ave*min(0.96,e*m_av)#e是一个用来调节的参数，当e值越大时，去雾后的图像就越暗，去雾效果就越明显，e值越小时，图像偏白，有明显的雾气
    L=np.zeros((h,w))
    L=np.minimum(M,T)   
    A=0.5*(np.max(M)+np.max(M_ave))
    F=np.zeros((h,w))
    F= (img -L)/(1-L/A)  
    return F

def adjustContractAndBrithtness(img):
    contract=0.4#对比度
    brightness=0.5#亮度
    k = math.tan( (45 + 44 * contract) / 180 * math.pi )
    res = np.uint8(np.clip(((img- 127.5 * (1-brightness)) * k + 127.5 * (1+brightness)), 0, 255))##降低亮度，提升对比度
    return res


cv2.namedWindow('video',cv2.WINDOW_AUTOSIZE)
cap=cv2.VideoCapture('test7.mp4')#获取视频 0表示使用设备摄像头实时处理，‘test7’表示处理视频文件
while True:
    ret, frame=cap.read()
    vd=videoProcess(frame)
    cv2.imshow('Video',vd)
    key = cv2.waitKey(1)
    if(0xFF == ord('q')):
        break
cap.release()
cv2.destroyALLWindows()
    